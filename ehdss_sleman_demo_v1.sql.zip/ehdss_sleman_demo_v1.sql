-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2022 at 08:07 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ehdss_sleman_demo_v1`
--

-- --------------------------------------------------------

--
-- Table structure for table `demov2_data_result`
--

CREATE TABLE `demov2_data_result` (
  `id_data_result` int(11) NOT NULL,
  `idrt` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `hash` varchar(64) NOT NULL,
  `data` text NOT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Hasil upload data client';

--
-- Dumping data for table `demov2_data_result`
--

INSERT INTO `demov2_data_result` (`id_data_result`, `idrt`, `tanggal`, `hash`, `data`, `keterangan`) VALUES
(19, 'IDlb4ovfqhb7kge9djnbbz4njm', '2022-12-01 06:33:44', 'fa5e1a0fb5ed67c36f1d678dce2d8d0b', '{\"ir\":{\"idrt\":\"IDlb4ovfqhb7kge9djnbbz4njm\",\"ir02\":\"1980-12-11\",\"ir01\":\"koko\",\"ir03\":41,\"ir04\":\"1\",\"ir05\":\"089123123\",\"ir06\":\"4\",\"ir07\":\"4\",\"ir08\":\"1\",\"ir08a\":\"1\",\"ir08b\":\"1\",\"ir08c\":\"2\",\"ir09\":\"15\",\"ir10\":\"74\",\"ir11\":\"dusun\",\"ir12\":3,\"ir13\":4,\"ir14\":\"gang jeruk 77\",\"ir\":1},\"agh\":{\"e1\":1,\"e2b\":\"1\",\"e2aa\":\"apel\",\"e2a\":120,\"e2\":1.5,\"e3\":2,\"e4b\":\"1\",\"e4aa\":\"bayam\",\"e4a\":300,\"e4\":3.75,\"agh\":1,\"i1\":\"2\",\"i2\":\"3\",\"i3\":\"4\",\"i4\":\"98\",\"f1\":\"1\",\"f4\":\"1\",\"f2\":2,\"f3a\":2,\"f3b\":2,\"f5\":3,\"f6a\":3,\"f6b\":3,\"f13\":\"1\",\"f10\":\"1\",\"f7\":\"1\",\"f15a\":7,\"f15b\":7,\"f14\":7,\"f12a\":5,\"f12b\":5,\"f11\":5,\"f9a\":6,\"f9b\":6,\"f8\":6,\"g05\":\"1\",\"g06\":23,\"g07\":24,\"g08a1\":1},\"hl\":{\"hl01\":1,\"hl02\":2,\"hl03\":3,\"hl04\":4,\"hl05\":3,\"hl06\":2,\"hl07\":1,\"hl08\":2,\"hl09\":3,\"hl10\":4,\"hl\":1},\"srq\":{\"srq01\":2,\"srq02\":2,\"srq03\":2,\"srq04\":2,\"srq05\":2,\"srq06\":2,\"srq07\":2,\"srq08\":2,\"srq09\":2,\"srq10\":2,\"srq\":1},\"rt\":{\"idrt\":\"IDlb4ovfqhb7kge9djnbbz4njm\",\"ir02\":\"1980-12-11\",\"ir01\":\"koko\",\"ir03\":41,\"ir04\":\"1\",\"ir05\":\"089123123\",\"ir06\":\"4\",\"ir07\":\"4\",\"ir08\":\"1\",\"ir08a\":\"1\",\"ir08b\":\"1\",\"ir08c\":\"2\",\"ir09\":\"15\",\"ir10\":\"74\",\"ir11\":\"dusun\",\"ir12\":3,\"ir13\":4,\"ir14\":\"gang jeruk 77\",\"ir\":1},\"atr\":{\"atr01\":180,\"atr02\":70,\"atr03\":\"21.60\",\"atr\":1}}', NULL),
(20, 'IDlb4phlj1b28tn48f1ss3gM3', '2022-12-01 06:42:26', '938259eb75641e2af4d46b55af2fb239', '{\"ir\":{\"idrt\":\"IDlb4phlj1b28tn48f1ss3gM3\",\"ir02\":\"1980-11-30\",\"ir01\":\"roni\",\"ir03\":42,\"ir04\":\"1\",\"ir05\":\"089123123\",\"ir06\":\"1\",\"ir07\":\"2\",\"ir08\":\"1\",\"ir08a\":\"1\",\"ir08c\":\"2\",\"ir08b\":\"2\",\"ir09\":\"13\",\"ir10\":\"62\",\"ir11\":\"nama dusun\",\"ir12\":2,\"ir13\":3,\"ir\":1},\"agh\":{\"e1\":98,\"e2b\":\"98\",\"e3\":98,\"e4b\":\"98\",\"agh\":1,\"i1\":\"1\",\"i2\":\"2\",\"i3\":\"2\",\"i4\":\"2\",\"f1\":\"2\",\"f4\":\"2\",\"f7\":\"2\",\"f10\":\"2\",\"f13\":\"2\",\"g05\":\"2\",\"g07\":34,\"g08a2\":2,\"g08b2\":3},\"hl\":{\"hl01\":1,\"hl02\":2,\"hl03\":3,\"hl\":1,\"hl04\":3,\"hl05\":2,\"hl06\":3,\"hl07\":4,\"hl08\":2,\"hl09\":1,\"hl10\":1},\"srq\":{\"srq01\":1,\"srq03\":1,\"srq02\":1,\"srq04\":1,\"srq05\":1,\"srq06\":1,\"srq07\":1,\"srq08\":1,\"srq09\":1,\"srq10\":1,\"srq\":1},\"atr\":{\"atr01\":176,\"atr02\":50,\"atr03\":\"16.14\",\"atr\":1}}', NULL),
(21, 'IDlb4pmkge26cane768q6g1ERp', '2022-12-01 06:50:46', '140de583694a25d4efa4e14fe6c5356a', '{\"ir\":{\"idrt\":\"IDlb4pmkge26cane768q6g1ERp\",\"ir02\":\"1980-12-30\",\"ir01\":\"jojon\",\"ir03\":41,\"ir04\":\"1\",\"ir05\":\"081123132\",\"ir06\":\"3\",\"ir07\":\"5\",\"ir08\":\"1\",\"ir08a\":\"1\",\"ir08b\":\"2\",\"ir08c\":\"2\",\"ir09\":\"15\",\"ir10\":\"74\",\"ir11\":\"dusun\",\"ir12\":4,\"ir13\":4,\"ir14\":\"jalan kopi 88\",\"ir\":1},\"agh\":{\"e1\":6,\"e2b\":\"98\",\"e3\":6,\"e4b\":\"98\",\"agh\":1,\"i1\":\"2\",\"i2\":\"2\",\"i3\":\"3\",\"i4\":\"2\",\"f1\":\"2\",\"f7\":\"2\",\"f4\":\"2\",\"f10\":\"2\",\"f13\":\"2\",\"g05\":\"1\",\"g06\":98,\"g07\":98,\"g08a1\":98,\"g08b1\":98},\"hl\":{\"hl01\":2,\"hl02\":2,\"hl03\":1,\"hl04\":3,\"hl05\":4,\"hl07\":1,\"hl06\":3,\"hl08\":3,\"hl09\":4,\"hl10\":2,\"hl\":1},\"srq\":{\"srq01\":2,\"srq02\":2,\"srq03\":2,\"srq04\":2,\"srq05\":2,\"srq06\":2,\"srq07\":2,\"srq08\":2,\"srq09\":2,\"srq10\":2,\"srq\":1},\"atr\":{\"atr01\":180,\"atr02\":70,\"atr03\":\"21.60\",\"atr\":1}}', NULL),
(22, 'IDlb4pyqwwxifs25oc03nkwOQ', '2022-12-01 06:53:59', '97c484a9231bf5cf654a042705bf1c9a', '{\"ir\":{\"idrt\":\"IDlb4pyqwwxifs25oc03nkwOQ\",\"ir02\":\"1972-11-29\",\"ir01\":\"jojon\",\"ir03\":50,\"ir04\":\"1\",\"ir05\":\"089123123\",\"ir06\":\"3\",\"ir07\":\"8\",\"ir08\":\"2\",\"ir09\":\"12\",\"ir10\":\"55\",\"ir11\":\"kulon\",\"ir12\":3,\"ir13\":4,\"ir\":1},\"agh\":{\"e1\":98,\"e2b\":\"98\",\"e3\":98,\"e4b\":\"98\",\"agh\":1,\"i1\":\"2\",\"i2\":\"2\",\"i3\":\"2\",\"i4\":\"2\",\"f1\":\"2\",\"f4\":\"2\",\"f7\":\"2\",\"f10\":\"2\",\"f13\":\"2\",\"g05\":\"4\",\"g07\":34,\"g08a2\":4,\"g08b2\":4},\"hl\":{\"hl01\":2,\"hl02\":1,\"hl03\":3,\"hl04\":3,\"hl05\":2,\"hl06\":1,\"hl07\":3,\"hl08\":4,\"hl09\":1,\"hl10\":1,\"hl\":1},\"srq\":{\"srq01\":2,\"srq02\":1,\"srq03\":1,\"srq04\":2,\"srq05\":2,\"srq06\":1,\"srq07\":1,\"srq08\":1,\"srq09\":1,\"srq10\":2,\"srq\":1},\"atr\":{\"atr01\":190,\"atr02\":40,\"atr03\":\"11.08\",\"atr\":1}}', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `demov2_users`
--

CREATE TABLE `demov2_users` (
  `id_user` int(11) NOT NULL,
  `user` varchar(50) NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL DEFAULT '0' COMMENT 'md5(md5(password))',
  `role` varchar(255) NOT NULL DEFAULT '0' COMMENT 'enum, manajer, admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `demov2_users`
--

INSERT INTO `demov2_users` (`id_user`, `user`, `password`, `role`) VALUES
(140, 'riyan', '59cf8e8a53c0c81c742b87c52a89d24f', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `demov2_user_enum`
--

CREATE TABLE `demov2_user_enum` (
  `id_user_enum` int(11) NOT NULL,
  `user` varchar(50) NOT NULL DEFAULT '0',
  `enum` varchar(50) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User supervisor has enum';

--
-- Dumping data for table `demov2_user_enum`
--

INSERT INTO `demov2_user_enum` (`id_user_enum`, `user`, `enum`) VALUES
(6, 'spv', 'enum'),
(7, 'spv', 'enum1'),
(8, 'spv', 'enum2');

-- --------------------------------------------------------

--
-- Table structure for table `demov2_user_rt`
--

CREATE TABLE `demov2_user_rt` (
  `id_user_rt` int(11) NOT NULL,
  `user` varchar(50) NOT NULL DEFAULT '0',
  `idrt` int(11) NOT NULL DEFAULT 0,
  `tgl` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `demov2_data_result`
--
ALTER TABLE `demov2_data_result`
  ADD PRIMARY KEY (`id_data_result`),
  ADD KEY `hash` (`hash`),
  ADD KEY `idrt` (`idrt`(255)),
  ADD KEY `tanggal` (`tanggal`);

--
-- Indexes for table `demov2_users`
--
ALTER TABLE `demov2_users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `IdxUser` (`user`);

--
-- Indexes for table `demov2_user_enum`
--
ALTER TABLE `demov2_user_enum`
  ADD PRIMARY KEY (`id_user_enum`);

--
-- Indexes for table `demov2_user_rt`
--
ALTER TABLE `demov2_user_rt`
  ADD PRIMARY KEY (`id_user_rt`),
  ADD UNIQUE KEY `idx_idrt_rt` (`idrt`),
  ADD KEY `idx_user_rt` (`user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `demov2_data_result`
--
ALTER TABLE `demov2_data_result`
  MODIFY `id_data_result` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `demov2_users`
--
ALTER TABLE `demov2_users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=192;

--
-- AUTO_INCREMENT for table `demov2_user_enum`
--
ALTER TABLE `demov2_user_enum`
  MODIFY `id_user_enum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `demov2_user_rt`
--
ALTER TABLE `demov2_user_rt`
  MODIFY `id_user_rt` int(11) NOT NULL AUTO_INCREMENT;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
